// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "CharacterBase.generated.h"

// ������ ( ���� �Է� ��Ʈ���� �����ϱ� ����).
UENUM()
enum class ECharacterControlViewType : uint8
{
	Shoulder,
	Quarter,
};


UCLASS()
class NEVERNESS_API ACharacterBase : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	ACharacterBase();

protected:
	void SetCharacterViewControl(ECharacterControlViewType NewCharacterControlViewType);

};
